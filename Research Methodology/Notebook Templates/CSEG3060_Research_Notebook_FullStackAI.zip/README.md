# CSEG3060 Research Notebook — Full Stack AI track

Template for the individual Research Notebook required in
**CSEG3060 · Research Methodology in Computer Science**,
School of Computer Science, UPES.
Instructor: **Dr. Mohsin Furkh Dar**, Cloud & Software Operations Cluster.

---

## Start here (students)

1. **Make your own copy.** In Overleaf: `Menu → Copy Project`. Never edit the
   shared template directly — your work would be visible to everyone and could
   be overwritten.
2. **Fill in your details.** Open `main.tex` and edit the block marked
   `STEP 1` — name, SAP ID, batch, track, email. Nothing else in `main.tex`
   needs changing.
3. **Recompile.** The compiler is **pdfLaTeX** (Overleaf's default). If
   citations appear as `[?]`, compile a second time.
4. **After every lecture, add something.** Open the file in `sections/` that
   matches the topic, write your entry, and add a line to the *Lecture log* on
   page 3.
5. **Add every paper you read to `references.bib`**, then cite it with
   `\citet{key}` or `\cite{key}`.
6. **Delete the grey WORKED EXAMPLE boxes** once you have written your own
   version of that section. They exist to show you the shape of a good answer,
   not to be submitted.

---

## What is in the project

```
main.tex                 <- your details go here; nothing else to edit
researchnotebook.sty     <- styling and the box macros; do not edit
references.bib           <- your bibliography (starter entries included)
figures/                 <- put your pipeline diagram and result figures here
sections/
  00-frontmatter.tex     <- title page, how-to, lecture log
  01-research-interest.tex
  02-problem-ideas.tex
  03-problem-statement.tex
  04-research-questions.tex
  05-research-objectives.tex
  06-literature-papers.tex
  07-literature-matrix.tex     <- landscape comparison table
  08-research-gap.tex
  09-methodology.tex
  10-dataset.tex
  11-experimental-plan.tex
  12-evaluation-metrics.tex
  13-ethics.tex
  14-research-proposal.tex
  15-final-presentation.tex
```

Each section file contains four or five boxes:

| Box | Colour | What to do with it |
|---|---|---|
| **WHAT THIS SECTION IS FOR** | blue | Read it first. |
| **COMMON TRAP** | amber | The mistake most students make here. |
| **WORKED EXAMPLE** | grey | A complete example. **Delete it** once you write your own. |
| **YOUR WORK** | black frame | Where you write. |
| **DONE WHEN** | teal | Checklist to test yourself against. |

The worked example is **one research idea carried through all fifteen
sections**, so you can see how a single problem evolves rather than reading
fifteen unrelated snippets.

---

## Commands you will use

| Command | What it does |
|---|---|
| `\fillme{a one-sentence question}` | Grey italic placeholder. Replace it. |
| `\version{2}{2026-09-03}{after Lecture I.6}` | Stamps a revision, so the evolution of your thinking stays visible. |
| `\wasnow{old wording}{new wording}` | Strikes the old wording, shows the new. |
| `\rnsub{A sub-heading}` | A heading inside a box. |
| `\todo{find the dataset licence}` | An amber reminder to yourself. |
| `\citet{key}` / `\cite{key}` | Cites a paper from `references.bib`. |
| `\blankcell` | A ruled blank cell inside a table. |

**Do not overwrite your earlier answers.** Rule 3 of the course brief is that
the notebook must show how your idea developed. Use `\version{...}` to append a
revision underneath the earlier text.

---

## Compiling locally instead of on Overleaf

```
pdflatex main
bibtex   main
pdflatex main
pdflatex main
```

Requires a standard TeX Live installation (`tcolorbox`, `xltabular`,
`pdflscape`, `natbib`, `enumitem`, `booktabs` — all present in
`texlive-latex-extra`).

---

## For the instructor

To publish this as a shared template:

1. Upload `CSEG3060_Research_Notebook_FullStackAI.zip` to Overleaf via `New Project → Upload Project`.
2. Compile once to confirm it builds.
3. `Menu → Share → Turn on link sharing → Anyone with this link can **view**`.
   Give students the **view** link, not the edit link — they take their own
   copy with `Menu → Copy Project`, which preserves the master.
4. Ask students to share their own project back with your email address
   (`Share → invite`, with *Can view*), or to submit the compiled PDF.
