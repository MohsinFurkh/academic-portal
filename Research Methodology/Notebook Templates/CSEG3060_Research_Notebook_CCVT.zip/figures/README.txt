Put your pipeline diagram and result figures here.
Include them with \includegraphics[width=\linewidth]{figures/pipeline.pdf}
